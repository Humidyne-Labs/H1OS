#!/usr/bin/env bash
set -e

echo "========================================================================="
echo "               H1OS Firmware Flasher Tool - 2.4.5"
echo "          Target Hardware: Waveshare ESP32-S3 ePaper 1.54 V2"
echo "========================================================================="
echo ""

PYTHON_CMD="python3"
if ! command -v python3 &> /dev/null; then
    if command -v python &> /dev/null; then
        PYTHON_CMD="python"
    else
        echo "[ERROR] python3 could not be found."
        exit 1
    fi
fi

if ! $PYTHON_CMD -m esptool version &> /dev/null; then
    echo "[WARNING] esptool not found. Attempting install..."
    $PYTHON_CMD -m pip install esptool
fi

PORT="${1}"
if [ -z "$PORT" ]; then
    echo "Available serial ports:"
    $PYTHON_CMD -m serial.tools.list_ports || true
    echo ""
    read -p "Enter serial port (e.g. /dev/ttyACM0 or /dev/cu.usbmodem*): " PORT
fi

if [ -z "$PORT" ]; then
    echo "[ERROR] No port provided."
    exit 1
fi

echo ""
echo "Select Flash Option:"
echo "[1] Full Factory Flash  - Monolithic Image (0x0, Clean Reinstall) [Recommended]"
echo "[2] Fast App Update     - Firmware Only (0x20000, Keeps Settings/NVS)"
echo "[3] Full Chip Erase     - Erase Entire Flash, then Full Factory Flash"
read -p "Enter choice (1, 2, or 3, default is 1): " CHOICE
CHOICE="${CHOICE:-1}"

echo ""
if [ "$CHOICE" = "1" ]; then
    echo "[INFO] Flashing factory image at 0x0..."
    $PYTHON_CMD -m esptool --chip esp32s3 -p "$PORT" -b 460800 --before default-reset --after hard-reset write-flash --flash-mode dio --flash-freq 80m --flash-size 8MB 0x0 "h1os-v2.4.5-factory.bin"
elif [ "$CHOICE" = "2" ]; then
    echo "[INFO] Flashing app payload at 0x20000..."
    $PYTHON_CMD -m esptool --chip esp32s3 -p "$PORT" -b 460800 --before default-reset --after hard-reset write-flash --flash-mode dio --flash-freq 80m --flash-size 8MB 0x20000 "h1os.bin"
elif [ "$CHOICE" = "3" ]; then
    echo "[WARNING] Erasing full flash..."
    $PYTHON_CMD -m esptool --chip esp32s3 -p "$PORT" erase-flash
    echo "[INFO] Flashing factory image at 0x0..."
    $PYTHON_CMD -m esptool --chip esp32s3 -p "$PORT" -b 460800 --before default-reset --after hard-reset write-flash --flash-mode dio --flash-freq 80m --flash-size 8MB 0x0 "h1os-v2.4.5-factory.bin"
else
    echo "[ERROR] Invalid selection."
    exit 1
fi

echo ""
echo "[SUCCESS] Flash completed successfully!"
