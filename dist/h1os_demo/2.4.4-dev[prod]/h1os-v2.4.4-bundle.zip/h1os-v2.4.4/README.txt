# H1OS 2.4.4 Firmware Release Bundle
Target: Waveshare ESP32-S3 ePaper 1.54" V2 (ESP32-S3-PICO-1-N8R8)
Commit: a241646
Date  : 2026-10-27 16:34:38

## Quick Start Flashing:

### On Windows:
1. Connect ESP32-S3 via USB-C.
2. Double-click `flash_now.bat`.
3. Choose option [1] for Full Factory Flash.

### On Linux / macOS:
```bash
chmod +x flash_now.sh
./flash_now.sh /dev/ttyACM0
```

### Manual Command via esptool:
```bash
python -m esptool --chip esp32s3 -b 460800 write-flash 0x0 h1os-v2.4.4-factory.bin
```

## Binary Contents:
- `h1os-v2.4.4-factory.bin`: Complete monolithic flash image (starts at 0x0).
- `h1os.bin`: Application payload only (starts at 0x20000).
- `bins/`: Individual modular partitions (bootloader, partition-table, ota_data).
